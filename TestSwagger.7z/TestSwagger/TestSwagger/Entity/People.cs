﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestSwagger.Entity
{
    /// <summary>
    /// 人类表
    /// </summary>
    public class People
    {
        /// <summary>
        /// 编号id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 名字
        /// </summary>
        public string Name { get; set; }
    }
}
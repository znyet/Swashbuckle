﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using Swashbuckle.Swagger.Annotations;
using TestSwagger.Entity;

namespace TestSwagger.Controller
{
    /// <summary>
    /// 人类控制器
    /// </summary>
    public class HomeController : ApiController
    {
        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">id参数</param>
        /// <returns>返回Get</returns>
        [HttpGet]
        public string Get(int id)
        {
            return "Get";
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="file">文件</param>
        /// <param name="name">名字</param>
        /// <param name="age">年龄</param>
        /// <returns>返回数据啦</returns>
        [HttpPost]
        public string PostFile([SgForm]string name, [SgForm]int age, [SgFile]string file = null)
        {
            return "PostFile";
        }

        /// <summary>
        /// 随便备注使用方法
        /// </summary>
        /// <param name="id">这是id</param>
        /// <remarks>
        /// 测试一些内容，不想将无用的东西放在接口名称当中<br/>
        /// 换行输出一下内容
        /// </remarks>
        /// <returns></returns>
        [HttpGet]
        public string Remark(int id)
        {
            return "这是备注";
        }

        /// <summary>
        /// 返回消息备注
        /// </summary>
        /// <param name="id">这是id</param>
        /// <returns></returns>
        [HttpGet]
        [SwaggerResponse(HttpStatusCode.OK, "返回实体内容描述", Type = typeof(People))]
        public string ResponseMessage(int id)
        {
            return "ResponseMessage";
        }


        /// <summary>
        /// 自定义消息和返回消息备注
        /// </summary>
        /// <param name="id">这是id</param>
        /// <remarks>
        /// 测试一些内容，不想将无用的东西放在接口名称当中<br/>
        /// 换行输出一下内容
        /// </remarks>
        /// <returns></returns>
        [HttpGet]
        [SwaggerResponse(HttpStatusCode.OK, "返回实体内容描述", Type = typeof(People))]
        public string Both(int id)
        {
            return "ResponseMessage";
        }


    }
    
}